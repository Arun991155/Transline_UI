package com.example.translineui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.translineui.R;

public class AttendanceMarked extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_marked);
    }
}